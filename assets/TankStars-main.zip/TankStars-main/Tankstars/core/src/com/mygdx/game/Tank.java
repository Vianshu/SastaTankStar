package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.actions.MoveByAction;
import com.badlogic.gdx.scenes.scene2d.actions.MoveToAction;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;


public class Tank extends Image {
    @Override
    public void draw(Batch batch,float percentage){
        ((TextureRegionDrawable)getDrawable()).draw(batch,getX(),getY()
                ,getOriginX(),getOriginY(),
                getWidth(),getHeight(),
                getScaleX(),getScaleY(),
                getRotation());}
    public Tank(Texture texture) {
        super(texture);

        setBounds(getX(), getY(), getWidth(), getHeight());
        boolean b = addListener(new InputListener() {
            @Override
            public boolean keyDown(InputEvent event, int keycode) {
                switch (keycode) {
                    case Input.Keys.W:
                        MoveToAction mta = new MoveToAction();
                        mta.setPosition(200f,200f);
                        mta.setDuration(5f);
//                        mta.setY(mta.getY()+5);
                        Tank.this.addAction(mta);
                        break;
                    case Input.Keys.A:
                        MoveToAction mta2 = new MoveToAction();
                        mta2.setY(mta2.getX()-5);
                        break;
                    case Input.Keys.S:

                        MoveToAction mta3 = new MoveToAction();
                        mta3.setY(mta3.getY()-5);
                        break;
                    case Input.Keys.D:

                        MoveToAction mta4 = new MoveToAction();
                        mta4.setY(mta4.getX()+5);
                        break;
                }
                return true;
            }
        });
    }
}