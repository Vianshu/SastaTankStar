package com.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.Scenes.Hud;
import com.mygdx.game.Screens.MainScreen;
import com.mygdx.game.Screens.menuscreen;

public class MyGdxGame extends Game {
	public SpriteBatch batch;

	public static final int V_width=800;
	public static final int V_Height=480;
	@Override
	public void create () {
		batch = new SpriteBatch();
		setScreen(new menuscreen(this));
//		setScreen(new Hud(this));
	}
	@Override
	public void render () {
		super.render();
	}
	@Override
	public void dispose () {
		super.dispose();
	}
}
